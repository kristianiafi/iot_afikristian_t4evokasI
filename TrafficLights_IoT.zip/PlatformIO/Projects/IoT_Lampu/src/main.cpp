#include <Arduino.h>

int lightHijau = 33;
int lightKuning = 26;
int lightMerah = 14;

void setup() {
  pinMode(lightHijau, OUTPUT);
  pinMode(lightKuning, OUTPUT);
  pinMode(lightMerah, OUTPUT);
}

void loop() {
  // Hijau menyala 0.5 detik
  digitalWrite(lightHijau, HIGH);
  delay(500);
  digitalWrite(lightHijau, LOW);

  // Kuning menyala 0.4 detik
  digitalWrite(lightKuning, HIGH);
  delay(400);
  digitalWrite(lightKuning, LOW);

  // Merah menyala 0.5 detik
  digitalWrite(lightMerah, HIGH);
  delay(500);
  digitalWrite(lightMerah, LOW);
}